import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService, CartItemDto, computeMultiplier } from '../../service/cart/CartService';
import { Router } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-shopping-cart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './shopping-cart.html',
  styleUrl: './shopping-cart.css',
})
export class ShoppingCart implements OnInit {
  cartItems: CartItemDto[] = [];
  isLoading = true;
  errorMsg = '';
  isCheckingOut = false;

  constructor(
    private cartService: CartService,
    private router: Router,
    private sanitizer: DomSanitizer,
  ) {}
  ngOnInit(): void {
    this.loadCart();
  }

  loadCart(): void {
    this.isLoading = true;
    this.cartService.getCart().subscribe({
      next: (items) => {
        // console.log('Cart response:', items);
        this.cartItems = items.map((item) => this.mapImageUrl(item));
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Cart error:', err);
        this.errorMsg = 'Cart load nahi ho saka. Dobara try karein.';
        this.isLoading = false;
      },
    });
  }

  private mapImageUrl(item: CartItemDto): CartItemDto {
    let finalImageUrl: string | SafeUrl = 'assets/images/placeholder.png';

    if (item.productImageUrl) {
      finalImageUrl = this.sanitizer.bypassSecurityTrustUrl(
        `data:image/jpeg;base64,${item.productImageUrl}`,
      );
    }

    const mapped = { ...item, productImageUrl: finalImageUrl };
    mapped.subtotal = this.getUnitPrice(mapped) * mapped.quantity; // <-- this line is required
    return mapped;
  }

  removeItem(productId: string): void {
    this.cartService.removeItem(productId).subscribe({
      next: () => {
        // Local se bhi hata do — API call nahi padega dobara
        this.cartItems = this.cartItems.filter((item) => item.productId !== productId);
      },
      error: () => {
        this.errorMsg = 'Item remove nahi ho saka.';
      },
    });
  }

  increaseQuantity(item: CartItemDto): void {
    const newQty = item.quantity + 1;
    this.cartService.updateQuantity(item.productId, newQty).subscribe({
      next: () => {
        item.quantity = newQty;
        item.subtotal = this.getUnitPrice(item) * item.quantity;
      },
      error: () => {
        this.errorMsg = 'No more sufficient quantity';
      },
    });
  }

  decreaseQuantity(item: CartItemDto): void {
    if (item.quantity <= 1) {
      this.removeItem(item.productId);
      return;
    }
    const newQty = item.quantity - 1;
    this.cartService.updateQuantity(item.productId, newQty).subscribe({
      next: () => {
        item.quantity = newQty;
        item.subtotal = this.getUnitPrice(item) * item.quantity;
      },
      error: () => {
        this.errorMsg = 'Quantity has not updated';
      },
    });
  }

  checkout(): void {
    if (this.cartItems.length === 0) {
      this.errorMsg = 'Cart is empty, please add item to cart';
      return;
    }
    this.isCheckingOut = true;
    this.cartService.checkout().subscribe({
      next: () => {
        this.cartItems = [];
        this.isCheckingOut = false;
        this.router.navigate(['/orders']);
      },
      error: () => {
        this.errorMsg = 'Order does not placed';
        this.isCheckingOut = false;
      },
    });
  }

  get totalAmount(): number {
    return this.cartItems.reduce((sum, item) => sum + item.subtotal, 0);
  }

  get totalItems(): number {
    return this.cartItems.reduce((sum, item) => sum + item.quantity, 0);
  }

  getWeight(item: CartItemDto): string {
    return item.weight || this.cartService.getSelectedWeight(item.productId);
  }

  /** Price for ONE unit at the selected weight (₹1000/kg + 250g => ₹250) */
  getUnitPrice(item: CartItemDto): number {
    const multiplier = computeMultiplier(this.getWeight(item), item.unit);
    return Math.round(item.pricePerUnit * multiplier * 100) / 100;
  }
}
