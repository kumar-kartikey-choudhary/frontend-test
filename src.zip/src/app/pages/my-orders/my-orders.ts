import { environment } from '../../../environments/environment';
// src/app/pages/my-orders/my-orders.component.ts

import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DatePipe, DecimalPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

interface OrderItemDto {
  id: string;
  productId: string;
  productName: string;
  imageData: string | SafeUrl; // base64 string from backend, sanitized before display
  quantity: number;
  price: number;
  subTotal: number;
}

// NOTE: confirm this matches every value in your backend OrderStatus enum exactly
// (seen so far: PROCESSING, CONFIRMED — add SHIPPED/DELIVERED/CANCELLED etc. as needed)
type OrderStatus = 'PROCESSING' | 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';

interface OrderResponse {
  id: string;
  orderDateTime: string; // ISO string over the wire; DatePipe parses it fine
  status: OrderStatus;
  totalAmount: number;
  items: OrderItemDto[];
}

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.html',
  styleUrls: ['./my-orders.css'],
  standalone: true,
  imports: [RouterLink, DatePipe, DecimalPipe],
})
export class MyOrders implements OnInit {
  orders: OrderResponse[] = [];
  isLoading = true;
  errorMsg = '';

  private orderUrl = `${environment.apiBaseUrl}/orders/findByCustomer`;

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer,
  ) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(): void {
    this.isLoading = true;
    this.http.get<OrderResponse[]>(this.orderUrl).subscribe({
      next: (data) => {
        this.orders = data.map((order) => ({
          ...order,
          items: order.items.map((item) => this.mapItemImage(item)),
        }));
        this.isLoading = false;
      },
      error: () => {
        this.errorMsg = 'Could not load your orders. Please try again.';
        this.isLoading = false;
      },
    });
  }

  private mapItemImage(item: OrderItemDto): OrderItemDto {
    if (item.imageData) {
      return {
        ...item,
        imageData: this.sanitizer.bypassSecurityTrustUrl(
          `data:image/jpeg;base64,${item.imageData}`,
        ),
      };
    }
    return { ...item, imageData: 'assets/images/placeholder.png' };
  }
}