import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export type OrderStatus = 'PROCESSING' | 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';

export interface OrderItemDto {
  id: string;
  productId: string;
  productName: string;
  imageData: string; // base64 string as returned by Jackson for byte[]
  quantity: number;
  price: number;
  subTotal: number;
}

export interface OrderResponse {
  id: string;
  username: string;
  orderDateTime: string; // ISO string over the wire
  status: OrderStatus;
  totalAmount: number;
  items: OrderItemDto[];
}

@Injectable({
  providedIn: 'root',
})
export class OrderAdminService {
  private readonly API_URL = 'http://localhost:8080/orders';

  constructor(private http: HttpClient) {}

  /** Admin: fetch every order across all customers. */
  getAllOrders(): Observable<OrderResponse[]> {
    return this.http.get<OrderResponse[]>(`${this.API_URL}/admin/findAll`);
  }

  /** Admin: change an order's status. */
  updateStatus(orderId: string, status: OrderStatus): Observable<OrderResponse> {
    const url = `${this.API_URL}/admin/updateStatus/${orderId}?status=${status}`;
    return this.http.put<OrderResponse>(url, {});
  }

  /** Admin: delete an order. */
  deleteOrder(orderId: string): Observable<void> {
    return this.http.delete<void>(`${this.API_URL}/admin/delete/${orderId}`);
  }
}